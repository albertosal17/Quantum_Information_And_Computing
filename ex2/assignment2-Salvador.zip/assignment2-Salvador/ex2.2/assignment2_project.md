---
project: Assignment2
author: Alberto Salvador
---

Assignment 2 of the course in "Quantum Information and Computing" at University of Padua.

